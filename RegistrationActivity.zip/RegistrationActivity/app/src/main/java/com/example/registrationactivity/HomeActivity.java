package com.example.registrationactivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {
    private DatabaseReference dbRef;
    private String userId;
    private TextView tvBalance;
    private FloatingActionButton fabAdd;
    private RecyclerView rvTransactions;
    private TransactionAdapter adapter;
    private ArrayList<Transaction> transactions;
    private double balance = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvBalance = findViewById(R.id.tvBalance);
        fabAdd = findViewById(R.id.fabAdd);
        rvTransactions = findViewById(R.id.rvTransactions);

        transactions = new ArrayList<>();
        adapter = new TransactionAdapter(transactions);
        rvTransactions.setLayoutManager(new LinearLayoutManager(this));
        rvTransactions.setAdapter(adapter);

        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        dbRef = FirebaseDatabase.getInstance()
                .getReference("users")
                .child(userId)
                .child("transactions");

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                transactions.clear();
                balance = 0.0;
                for (DataSnapshot transSnapshot : snapshot.getChildren()) {
                    Transaction t = transSnapshot.getValue(Transaction.class);
                    if (t != null) {
                        transactions.add(0, t);
                        balance += t.type.equals("Ingreso") ? t.amount : -t.amount;
                    }
                }
                adapter.notifyDataSetChanged();
                updateBalanceText();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(HomeActivity.this, "Error al cargar transacciones", Toast.LENGTH_SHORT).show();
            }
        });

        updateBalanceText();
        fabAdd.setOnClickListener(v -> showTransactionDialog());
    }

    private void showTransactionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Nueva transacción");
        builder.setItems(new CharSequence[]{"Agregar dinero", "Quitar dinero"}, (dialog, which) -> {
            if (which == 0) addTransaction(true);
            else addTransaction(false);
        });
        builder.show();
    }

    private void addTransaction(boolean isAdd) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isAdd ? "Agregar dinero" : "Quitar dinero");

        // Crear campos para descripción y cantidad
        final EditText inputDesc = new EditText(this);
        inputDesc.setHint("Descripción (Ej: Comida, Renta...)");

        final EditText inputAmount = new EditText(this);
        inputAmount.setHint("Cantidad (Ej: 100.50)");
        inputAmount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        // Crear layout vertical para ambos
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);
        layout.addView(inputDesc);
        layout.addView(inputAmount);

        builder.setView(layout);

        builder.setPositiveButton("OK", (dialog, which) -> {
            try {
                String desc = inputDesc.getText().toString().trim();
                double amount = Double.parseDouble(inputAmount.getText().toString());

                if (desc.isEmpty()) {
                    Toast.makeText(this, "Ingrese una descripción", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!isAdd && amount > balance) {
                    Toast.makeText(this, "No hay suficiente saldo", Toast.LENGTH_SHORT).show();
                    return;
                }

                Transaction t = new Transaction(isAdd ? "Ingreso" : "Gasto", amount, desc);

                dbRef.push().setValue(t);
                transactions.add(0, t);
                balance = isAdd ? balance + amount : balance - amount;
                adapter.notifyItemInserted(0);
                rvTransactions.scrollToPosition(0);
                updateBalanceText();

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Cantidad inválida", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    private void updateBalanceText() {
        tvBalance.setText(String.format("Saldo: $%.2f", balance));
    }

    public void logout() {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(HomeActivity.this, MainActivity.class));
        finish();
    }
}
