package com.example.registrationactivity;

public class Transaction {
    public String type;        // "Ingreso" o "Gasto"
    public double amount;      // Monto
    public String description; // Nueva descripción (ej: Comida, Renta, etc.)

    // 🔹 Constructor vacío requerido por Firebase
    public Transaction() {}

    // 🔹 Nuevo constructor completo
    public Transaction(String type, double amount, String description) {
        this.type = type;
        this.amount = amount;
        this.description = description;
    }
}
