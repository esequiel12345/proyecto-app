// Top-level build file
plugins {
    alias(libs.plugins.android.application) apply false  // solo declarar
    id("com.google.gms.google-services") version "4.4.3" apply false
}
